﻿CREATE DATABASE QuanLyCafe2;
GO

USE QuanLyCafe2;
GO
CREATE TABLE NhanVien
(
    MaNV INT PRIMARY KEY ,
    TenNV NVARCHAR(100) ,
    GioiTinh NVARCHAR(10) ,
    Email VARCHAR(100) ,
    DiaChi NVARCHAR(100) ,
    SDT VARCHAR(15) 
);
CREATE TABLE SanPham
(
    MaSP INT PRIMARY KEY ,
    TenSP NVARCHAR(100) ,
    SoLuong INT ,
    Gia DECIMAL(10, 2) ,
    KichThuoc VARCHAR(10)
);

CREATE TABLE ChuongTrinhKhuyenMai
(
    MaKM INT PRIMARY KEY ,
    TenChuongTrinh NVARCHAR(100) ,
    NgayBatDau DATE ,
    NgayKetThuc DATE ,
    ChietKhau DECIMAL(5, 2) ,
    MoTa TEXT 
);



CREATE TABLE DoanhThu
(
    MaDoanhThu INT PRIMARY KEY ,
    Ngay DATE ,
    Tien MONEY ,
    MaNV INT ,
    FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);

CREATE TABLE ChiTietKhuyenMai
(
    MaKM INT ,
    MaSP INT ,
    PRIMARY KEY (MaKM, MaSP),
    FOREIGN KEY (MaKM) REFERENCES ChuongTrinhKhuyenMai(MaKM),
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);

CREATE TABLE NguoiDung
(
    MaNguoiDung INT PRIMARY KEY ,
    TenTaiKhoan NVARCHAR(100) ,
    MatKhau NVARCHAR(100) ,
    MaNV INT ,
    FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);

CREATE TABLE HoaDon
(
    MaHD INT PRIMARY KEY ,
    Tong DECIMAL(10, 2) ,
    NgayDat DATE ,
    MaNV INT ,
    KichThuoc VARCHAR(10),
    FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);

CREATE TABLE HoaDonChiTiet
(
    MaHD INT ,
    MaSP INT ,
    TenSP NVARCHAR(100) ,
    SoLuong INT ,
    Gia DECIMAL(10, 2) ,
    PRIMARY KEY (MaHD, MaSP),
    FOREIGN KEY (MaHD) REFERENCES HoaDon(MaHD),
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);
GO
INSERT INTO NhanVien (MaNV, TenNV, GioiTinh, Email, DiaChi, SDT) VALUES
(1, N'Nguyễn Văn Phát', N'Nam', 'nguyenvanphat@gmail.com', N'123 Đường ABC, Quận 1, TP. HCM', '0912345678'),
(2, N'Chu Bích', N'Nữ', 'chubich@gmail.com', N'456 Đường XYZ, Quận 2, TP. HCM', '0912345679'),
(3, N'Lê Thị Thanh Nguyên', N'Nữ', 'lenguyen@gmail.com', N'789 Đường MNO, Quận 3, TP. HCM', '0912345680'),
(4, N'Đặng Thành Nguyên', N'Nam', 'nguyendang@gmail.com', N'123 Đường PQR, Quận 4, TP. HCM', '0912345681'),
(5, N'Admin', N'Nam', 'minmin@gmail.com', N'123 Đường ABC, Quận 7, TP. HCM', '0256314789');
GO
-- Chèn dữ liệu vào bảng SanPham
INSERT INTO SanPham (MaSP, TenSP, SoLuong, Gia, KichThuoc) VALUES
(1, N'Cà phê đen', 100, 20000.00, N'M'),
(2, N'Cà phê sữa', 150, 25000.00, N'L'),
(3, N'Trá xanh', 200, 15000.00, N'S'),
(4, N'Nước cam', 100, 30000.00, N'M'),
(5, N'Sinh tố bơ', 80, 40000.00, N'L'),
(6, N'Nước chanh', 120, 20000.00, N'S'),
(7, N'Nước dừa', 130, 25000.00, N'M'),
(8, N'Sinh tố xoài', 110, 30000.00, N'L'),
(9, N'Sinh tố dâu', 90, 35000.00, N'S'),
(10, N'Sữa chua', 95, 40000.00, N'M'),
(11, N'Cà phê sữa', 150, 20000.00, N'M'),
(12, N'Cà phê sữa', 150, 15000.00, N'S'),
(13, N'Cà phê đen', 150, 15000.00, N'S'),
(14, N'Trá xanh', 150, 20000.00, N'M'),
(15, N'Trá xanh', 120, 25000.00, N'L'),
(16, N'Nước cam', 170, 35000.00, N'L'),
(17, N'Nước cam', 130, 20000.00, N'S'),
(18, N'Sinh tố bơ', 150, 30000.00, N'M'),
(19, N'Sinh tố bơ', 150, 25000.00, N'S'),
(20, N'Nước chanh', 120, 25000.00, N'M'),
(21, N'Nước chanh', 110, 30000.00, N'L'),
(22, N'Nước dừa', 110, 30000.00, N'L'),
(23, N'Nước dừa', 110, 20000.00, N'S'),
(24, N'Sinh tố xoài', 100, 20000.00, N'S'),
(25, N'Sinh tố xoài', 110, 25000.00, N'M'),
(26, N'Sinh tố dâu', 110, 40000.00, N'M'),
(27, N'Sinh tố dâu', 110, 25000.00, N'L'),
(28, N'Sữa chua', 95, 30000.00, N'S'),
(29, N'Sữa chua', 95, 35000.00, N'L'),
(30, N'Cà phê đen', 160, 20000.00, N'L');
GO

-- Chèn dữ liệu vào bảng ChuongTrinhKhuyenMai
INSERT INTO ChuongTrinhKhuyenMai (MaKM, TenChuongTrinh, NgayBatDau, NgayKetThuc, ChietKhau, MoTa) VALUES
(1, N'Khuyến mãi mùa hè', '2024-06-01', '2024-06-30', 10.00, N'Giảm giá 10% cho tất cả các sản phẩm'),
(2, N'Khuyến mãi mùa đông', '2024-12-01', '2024-12-31', 15.00, N'Giảm giá 15% cho tất cả các sản phẩm'),
(3, N'Khuyến mãi ngày lễ', '2024-09-01', '2024-09-15', 20.00, N'Giảm giá 20% cho tất cả các sản phẩm nhân dịp lễ quốc khánh'),
(4, N'Khuyến mãi trung thu', '2024-09-21', '2024-09-30', 15.00, N'Giảm giá 15% cho tất cả các sản phẩm nhân dịp trung thu'),
(5, N'Khuyến mãi khai trường', '2024-01-01', '2024-01-15', 25.00, N'Giảm giá 25% cho tất cả các sản phẩm nhân dịp khai trường'),
(6, N'Khuyến mãi Giáng sinh', '2024-12-15', '2024-12-25', 20.00, N'Giảm giá 20% cho tất cả các sản phẩm nhân dịp Giáng sinh'),
(7, N'Khuyến mãi Tết', '2024-01-20', '2024-01-30', 30.00, N'Giảm giá 30% cho tất cả các sản phẩm nhân dịp Tết'),
(8, N'Khuyến mãi Valentine', '2024-02-10', '2024-02-14', 25.00, N'Giảm giá 25% cho tất cả các sản phẩm nhân dịp Valentine'),
(9, N'Khuyến mãi Quốc tế Phụ nữ', '2024-03-08', '2024-03-10', 20.00, N'Giảm giá 20% cho tất cả các sản phẩm nhân dịp 8/3'),
(10, N'Khuyến mãi ngày của mẹ', '2024-05-10', '2024-05-12', 15.00, N'Giảm giá 15% cho tất cả các sản phẩm nhân dịp ngày của mẹ');
GO

-- Chèn dữ liệu vào bảng NhanVien


-- Chèn dữ liệu vào bảng DoanhThu
INSERT INTO DoanhThu (MaDoanhThu, Ngay, Tien, MaNV) VALUES
(1, '2024-07-01', 5000000, 1),
(2, '2024-07-02', 7000000, 2),
(3, '2024-07-03', 6000000, 3),
(4, '2024-07-04', 8000000, 4),
(5, '2024-07-05', 7500000, 1); -- Sửa thành mã nhân viên hợp lệ
GO

-- Chèn dữ liệu vào bảng ChiTietKhuyenMai
INSERT INTO ChiTietKhuyenMai (MaKM, MaSP) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4),
(3, 5),
(3, 6),
(4, 7),
(4, 8),
(5, 9),
(5, 10);
GO

-- Chèn dữ liệu vào bảng NguoiDung
INSERT INTO NguoiDung (MaNguoiDung, TenTaiKhoan, MatKhau, MaNV) VALUES
(1, N'phatnguyen', N'123456', 1),
(2, N'bichchu', N'123456', 2),
(3, N'nguyenle', N'123456', 3),
(4, N'nguyendang', N'123456', 4),
(5, N'admin', N'admin', 5);
GO

-- Chèn dữ liệu vào bảng HoaDon
INSERT INTO HoaDon (MaHD, Tong, NgayDat, MaNV, KichThuoc) VALUES
(1, 150000.00, '2024-07-01', 1, 'M'),
(2, 250000.00, '2024-07-02', 2, 'L'),
(3, 350000.00, '2024-07-03', 3, 'S'),
(4, 450000.00, '2024-07-04', 4, 'M'),
(5, 550000.00, '2024-07-05', 1, 'L'); -- Sửa thành mã nhân viên hợp lệ
GO

-- Chèn dữ liệu vào bảng HoaDonChiTiet
INSERT INTO HoaDonChiTiet (MaHD, MaSP, TenSP, SoLuong, Gia) VALUES
(1, 1, N'Cà phê đen', 2, 20000.00),
(1, 2, N'Cà phê sữa', 1, 25000.00),
(2, 3, N'Trá xanh', 3, 15000.00),
(2, 4, N'Nước cam', 2, 30000.00),
(3, 5, N'Sinh tố bơ', 1, 40000.00),
(3, 6, N'Nước chanh', 2, 20000.00),
(4, 7, N'Nước dừa', 1, 25000.00),
(4, 8, N'Sinh tố xoài', 2, 30000.00),
(5, 9, N'Sinh tố dâu', 1, 35000.00),
(5, 10, N'Sữa chua', 1, 40000.00)

GO

