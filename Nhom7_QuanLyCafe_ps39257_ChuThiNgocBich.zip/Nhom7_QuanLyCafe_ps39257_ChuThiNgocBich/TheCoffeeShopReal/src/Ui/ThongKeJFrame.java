/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Ui;

import java.awt.Color;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class ThongKeJFrame extends javax.swing.JFrame {

    ResultSet rs, rsTK, rsInfoEmp, rsSPBan;
    Connection con;
    PreparedStatement ps, psTK, psSPBan;
    Server.DBHelper db = new Server.DBHelper();
    DefaultTableModel tblModel1, tblModel2;
    Vector row, vecSPBan;
    SimpleDateFormat ft = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat time = new SimpleDateFormat("HH:mm:ss dd/MM/yyyy");
    NumberFormat formatter = new DecimalFormat("####");

    public ThongKeJFrame() {
        initComponents();
        ImageIcon img = new ImageIcon("image//coffee.jpg");
        this.setIconImage(img.getImage());
        this.setLocationRelativeTo(null);
        btnPrint.setEnabled(false);
        
        // Setup table models
        setupTableModels();
        
        // Load data into tables
        loadTable();
        loadtblSP();
    }

    private void setupTableModels() {
        // Table model for ThongKe
        tblModel1 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblModel1.addColumn("Mã");
        tblModel1.addColumn("Ngày/tháng/năm");
        tblModel1.addColumn("Tiền thu (VNĐ)");
        tblThongKe1.setModel(tblModel1);
        
        // Table model for SanPham
        tblModel2 = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblModel2.addColumn("ID Sản phẩm");
        tblModel2.addColumn("Tên Sản phẩm");
        tblModel2.addColumn("Đơn giá");
        tblModel2.addColumn("Số lượng đã bán");
        tblSP.setModel(tblModel2);
    }

    private void loadTable() {
        try {
            con = db.getCon();
            ps = con.prepareStatement("SELECT * FROM DoanhThu ORDER BY MaDoanhThu DESC");
            rs = ps.executeQuery();
            while (rs.next()) {
                row = new Vector();
                row.add(rs.getString(1));
                row.add(rs.getString(2));
                row.add(formatter.format(rs.getInt(3)));
                tblModel1.addRow(row);
            }
            tblThongKe1.setModel(tblModel1);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi 101:: Không thể kết nối đến máy chủ");
        }

        int line = tblThongKe1.getRowCount();
        int tong = 0;

        for (int i = 0; i < line; i++) {
            try {
                String gia = (String) tblThongKe1.getValueAt(i, 2);
                gia = gia.replaceAll(",", ""); // Remove commas
                tong += Integer.parseInt(gia); // Convert to integer and add to total
            } catch (NumberFormatException e) {
                // Handle the case where parsing fails
                System.err.println("Error parsing value at row " + i + ": " + e.getMessage());
            }
        }

    }

        void loadtblSP() {
        tblModel2.getDataVector().removeAllElements(); // Xóa tất cả các hàng hiện tại trong mô hình bảng
        try {
            con = db.getCon();
            // Cập nhật truy vấn SQL để sắp xếp theo MaSP tăng dần
            psSPBan = con.prepareStatement("SELECT o.MaSP, p.TenSP, p.Gia, SUM(o.SoLuong) as Tong "
                                           + "FROM HoaDonChiTiet o JOIN SanPham p ON o.MaSP = p.MaSP "
                                           + "GROUP BY o.MaSP, p.TenSP, p.Gia ORDER BY o.MaSP ASC");
            rsSPBan = psSPBan.executeQuery();
            while (rsSPBan.next()) {
                vecSPBan = new Vector();
                vecSPBan.add(rsSPBan.getString("MaSP"));
                vecSPBan.add(rsSPBan.getString("TenSP"));
                vecSPBan.add(rsSPBan.getDouble("Gia"));
                vecSPBan.add(rsSPBan.getInt("Tong"));
                tblModel2.addRow(vecSPBan);
            }
            tblSP.setModel(tblModel2);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi tải dữ liệu sản phẩm bán nhiều nhất: " + e.getMessage());
            e.printStackTrace();
        }
    }



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        btnthoat = new javax.swing.JButton();
        btnmoi = new javax.swing.JButton();
        btnPrint = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        txttimkiem = new javax.swing.JLabel();
        txtDate = new javax.swing.JTextField();
        lbTong = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblThongKe1 = new javax.swing.JTable();
        lbLoi = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblSP = new javax.swing.JTable();
        btnTimKiem1 = new javax.swing.JButton();
        btnTimKiem2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        jLabel3.setText("jLabel3");

        jTextField2.setText("jTextField2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(235, 146, 12)));

        jTabbedPane1.setBackground(new java.awt.Color(204, 255, 204));
        jTabbedPane1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jTabbedPane1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTabbedPane1MouseClicked(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(204, 255, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel3MouseClicked(evt);
            }
        });

        btnthoat.setBackground(new java.awt.Color(235, 146, 12));
        btnthoat.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        btnthoat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Exit.png"))); // NOI18N
        btnthoat.setText("Thoát");
        btnthoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnthoatActionPerformed(evt);
            }
        });

        btnmoi.setBackground(new java.awt.Color(235, 146, 12));
        btnmoi.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        btnmoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8_refresh_30px.png"))); // NOI18N
        btnmoi.setText("Mới");
        btnmoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmoiActionPerformed(evt);
            }
        });

        btnPrint.setBackground(new java.awt.Color(235, 146, 12));
        btnPrint.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        btnPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Print.png"))); // NOI18N
        btnPrint.setText("Print");
        btnPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrintActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Tổng tiền:");

        txttimkiem.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txttimkiem.setText("Tìm kiếm theo ngày:");

        txtDate.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        txtDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDateActionPerformed(evt);
            }
        });

        lbTong.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        lbTong.setText("0 VNĐ");

        tblThongKe1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        tblThongKe1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "1", "2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tblThongKe1);

        lbLoi.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        lbLoi.setForeground(new java.awt.Color(255, 0, 0));
        lbLoi.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 757, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(19, 19, 19)
                                .addComponent(btnmoi)
                                .addGap(48, 48, 48)
                                .addComponent(btnPrint)
                                .addGap(363, 363, 363)
                                .addComponent(btnthoat))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbTong)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txttimkiem)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtDate, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lbLoi, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txttimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDate, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbTong))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(lbLoi, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnmoi)
                    .addComponent(btnthoat)
                    .addComponent(btnPrint, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43))
        );

        jTabbedPane1.addTab("Doanh Thu", jPanel3);

        jPanel2.setBackground(new java.awt.Color(204, 255, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        tblSP.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        tblSP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID Sản phẩm", "Tên sản phẩm", "Đơn giá", "Loại", "Số Lượng đã bán"
            }
        ));
        tblSP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblSPMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tblSP);
        if (tblSP.getColumnModel().getColumnCount() > 0) {
            tblSP.getColumnModel().getColumn(3).setHeaderValue("Loại");
        }

        btnTimKiem1.setBackground(new java.awt.Color(235, 146, 12));
        btnTimKiem1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        btnTimKiem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Search.png"))); // NOI18N
        btnTimKiem1.setText("Sản phẩm ít nhiều nhất");
        btnTimKiem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiem1ActionPerformed(evt);
            }
        });

        btnTimKiem2.setBackground(new java.awt.Color(235, 146, 12));
        btnTimKiem2.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        btnTimKiem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Search.png"))); // NOI18N
        btnTimKiem2.setText("Sản phẩm bán nhiều nhất");
        btnTimKiem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiem2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(btnTimKiem2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 146, Short.MAX_VALUE)
                .addComponent(btnTimKiem1)
                .addGap(92, 92, 92))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane4)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 456, Short.MAX_VALUE)
                .addGap(63, 63, 63)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnTimKiem2)
                    .addComponent(btnTimKiem1))
                .addGap(80, 80, 80))
        );

        jTabbedPane1.addTab("Thống Kê Sản Phẩm", jPanel2);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("BẢNG THỐNG KÊ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(251, 251, 251))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 12, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 780, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 667, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTabbedPane1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTabbedPane1MouseClicked
        // TODO add your handling code here:
      
    }//GEN-LAST:event_jTabbedPane1MouseClicked

    private void tblSPMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblSPMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tblSPMouseClicked

    private void btnTimKiem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiem1ActionPerformed
        tblModel2.getDataVector().removeAllElements(); // Xóa tất cả các hàng hiện tại trong mô hình bảng
    try {
        con = db.getCon();
        // Cập nhật truy vấn SQL để sắp xếp theo số lượng bán được (Tong) tăng dần
        psSPBan = con.prepareStatement("SELECT o.MaSP, p.TenSP, p.Gia, SUM(o.SoLuong) as Tong "
                                       + "FROM HoaDonChiTiet o JOIN SanPham p ON o.MaSP = p.MaSP "
                                       + "GROUP BY o.MaSP, p.TenSP, p.Gia ORDER BY Tong ASC");
        rsSPBan = psSPBan.executeQuery();
        while (rsSPBan.next()) {
            vecSPBan = new Vector();
            vecSPBan.add(rsSPBan.getString("MaSP"));
            vecSPBan.add(rsSPBan.getString("TenSP"));
            vecSPBan.add(rsSPBan.getDouble("Gia"));
            vecSPBan.add(rsSPBan.getInt("Tong"));
            tblModel2.addRow(vecSPBan);
        }
        tblSP.setModel(tblModel2);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Lỗi khi tải dữ liệu sản phẩm bán ít nhất: " + e.getMessage());
        e.printStackTrace();
    }
    }//GEN-LAST:event_btnTimKiem1ActionPerformed

    private void btnTimKiem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiem2ActionPerformed
        tblModel2.getDataVector().removeAllElements(); // Xóa tất cả các hàng hiện tại trong mô hình bảng
    try {
        con = db.getCon();
        // Cập nhật truy vấn SQL để sắp xếp theo số lượng bán được (Tong) giảm dần
        psSPBan = con.prepareStatement("SELECT o.MaSP, p.TenSP, p.Gia, SUM(o.SoLuong) as Tong "
                                       + "FROM HoaDonChiTiet o JOIN SanPham p ON o.MaSP = p.MaSP "
                                       + "GROUP BY o.MaSP, p.TenSP, p.Gia ORDER BY Tong DESC");
        rsSPBan = psSPBan.executeQuery();
        while (rsSPBan.next()) {
            vecSPBan = new Vector();
            vecSPBan.add(rsSPBan.getString("MaSP"));
            vecSPBan.add(rsSPBan.getString("TenSP"));
            vecSPBan.add(rsSPBan.getDouble("Gia"));
            vecSPBan.add(rsSPBan.getInt("Tong"));
            tblModel2.addRow(vecSPBan);
        }
        tblSP.setModel(tblModel2);
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Lỗi khi tải dữ liệu sản phẩm bán nhiều nhất: " + e.getMessage());
        e.printStackTrace();
    }
        
    }//GEN-LAST:event_btnTimKiem2ActionPerformed

    private void jPanel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel3MouseClicked

    private void txtDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDateActionPerformed
        // TODO add your handling code here:
        while (true) {
            if (!txtDate.getText().trim().matches("([0-9]{0,2}/)?([0-9]{0,2}/)?[0-9]{4}")) {
                lbLoi.setText("Nhập đúng định dạng để tìm kiếm: dd/MM/yyyy, MM/yyyy hoặc yyyy.");
                lbLoi.setForeground(Color.RED);
                btnPrint.setEnabled(false);
                return;
            } else {
                lbLoi.setText("");
                break;
            }
        }
        tblModel1.getDataVector().removeAllElements();
        try {
            ps = con.prepareStatement("select * from DoanhThu where Ngày like ?");
            ps.setString(1, "%" + (String) txtDate.getText().trim());
            rs = ps.executeQuery();
            if (rs.next()) {
                ps = con.prepareStatement("select * from DoanhThu where Ngày like ?");
                ps.setString(1, "%" + (String) txtDate.getText().trim());
                rs = ps.executeQuery();
                while (rs.next()) {
                    row = new Vector();
                    row.add(rs.getString(1));
                    row.add(rs.getString(2));
                    row.add(formatter.format(rs.getInt(3)));
                    tblModel1.addRow(row);

                    lbLoi.setText("Đã tìm thấy!");
                    lbLoi.setForeground(Color.BLUE);
                }
                tblThongKe1.setModel(tblModel1);
                btnPrint.setEnabled(true);
            } else {
                lbLoi.setText("Không tìm thấy dữ liệu!");
                lbLoi.setForeground(Color.RED);
                tblThongKe1.removeAll();
                btnPrint.setEnabled(false);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi 101:: Không thể kết nối đến máy chủ");
        }
        int line = tblThongKe1.getRowCount();
        int tong = 0;
        for (int i = 0; i < line; i++) {
            String price = (String) tblThongKe1.getValueAt(i, 2);
            tong += Integer.parseInt(price.replaceAll(",", ""));
        }
        lbTong.setText(formatter.format(tong) + " VNĐ");
    
    }//GEN-LAST:event_txtDateActionPerformed

    private void btnPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrintActionPerformed
        // TODO add your handling code here:
        File file = new File("DoanhThu.txt");
        file.delete();
        //Viết vào file txt
        try {
            Writer b = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("DoanhThu.txt"), "UTF8"));
            String a;
            Date now = new Date();

            b.write("\t\t\tTHE COFFEE SHOP\r\n\r\n");
            b.write("\t\t    CV Phần Mềm Quang Trung\r\n\r\n");
            b.write("\t\t\tSĐT: 0862346467\r\n\r\n");
            b.write("\tThời gian: " + ft.format(now) + "\r\n\r\n");
            if (txtDate.getText().trim().matches("[0-9]{0,2}/[0-9]{0,2}/[0-9]{4}")) {
                a = "ngày " + txtDate.getText().trim();
                b.write("\tBẢNG THỐNG KÊ DOANH THU (theo " + a + ")\r\n\r\n");
            } else if (txtDate.getText().trim().matches("[0-9]{0,2}/[0-9]{4}")) {
                a = "tháng " + txtDate.getText().trim();
                b.write("\tBẢNG THỐNG KÊ DOANH THU (theo " + a + ")\r\n\r\n");
            } else if (txtDate.getText().trim().matches("[0-9]{4}")) {
                a = "năm " + txtDate.getText().trim();
                b.write("\tBẢNG THỐNG KÊ DOANH THU (theo " + a + ")\r\n\r\n");
            }
            b.write("\t---------------------------------\r\n");
            b.write("\tID\tNgày thu\tSố tiền\r\n");
            b.write("\t---------------------------------\r\n");
            int line = tblThongKe1.getRowCount();
            for (int i = 0; i < line; i++) {
                String id = (String) tblThongKe1.getValueAt(i, 0);
                String date = (String) tblThongKe1.getValueAt(i, 1);
                String money = (String) tblThongKe1.getValueAt(i, 2);
                b.write("\t" + id + "\t" + date + "\t" + money + "\r\n");
            }
            b.write("\t---------------------------------\r\n");
            b.write("\tTổng tiền:\t\t" + lbTong.getText().trim() + "\r\n\r\n\r\n");
            b.write("\t\t\tNgười lập (Ký và ghi rõ họ tên)");
            b.close();
        } catch (IOException | NumberFormatException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        //Mở file txt
        Runtime run = Runtime.getRuntime();
        try {
            run.exec("notepad DoanhThu.txt");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        btnmoiActionPerformed(evt);
    }//GEN-LAST:event_btnPrintActionPerformed

    private void btnmoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmoiActionPerformed
        // TODO add your handling code here:
        tblModel1.getDataVector().removeAllElements();
        loadTable();
        btnPrint.setEnabled(false);
        lbLoi.setText("");
    }//GEN-LAST:event_btnmoiActionPerformed

    private void btnthoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnthoatActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_btnthoatActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ThongKeJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ThongKeJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ThongKeJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ThongKeJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ThongKeJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnPrint;
    private javax.swing.JButton btnTimKiem1;
    private javax.swing.JButton btnTimKiem2;
    private javax.swing.JButton btnmoi;
    private javax.swing.JButton btnthoat;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JLabel lbLoi;
    private javax.swing.JLabel lbTong;
    private javax.swing.JTable tblSP;
    private javax.swing.JTable tblThongKe1;
    private javax.swing.JTextField txtDate;
    private javax.swing.JLabel txttimkiem;
    // End of variables declaration//GEN-END:variables
}
